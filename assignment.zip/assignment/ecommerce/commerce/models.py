from django.db import models

# Create your models here.
class Customer(models.Model):
    customer_name = models.CharField(max_length=255,default='Unknown')
    address = models.CharField(max_length=200)

    def __str__(self):
        return self.customer_name

class Order(models.Model):
    customer = models.ForeignKey(Customer, default=1, related_name='orders', on_delete=models.CASCADE)
    order_date = models.DateTimeField(auto_now_add=True)



class OrderItem(models.Model):
    order = models.ForeignKey(Order, default=1, related_name='order_item', on_delete=models.CASCADE)
    item_name = models.CharField(max_length=200)
    quantity = models.IntegerField(default=1)

    def __str__(self):
        return self.item_name

