from django.contrib.auth.models import User
from rest_framework import serializers


from .models import Order

from .models import Customer, Order, OrderItem

class CustomerSerializer(serializers.ModelSerializer):
    customer_name = serializers.CharField(max_length=50, min_length=3, allow_blank=False, trim_whitespace=True)
    address = serializers.CharField(max_length=50, min_length=3, allow_blank=False, trim_whitespace=True)

    class Meta:
        model = Customer
        fields = ['customer_name','address']

class OrderSerializer(serializers.ModelSerializer):
    customer = serializers.PrimaryKeyRelatedField(queryset=Customer.objects.all())
    customer_details = CustomerSerializer(source='customer', read_only=True)
    order_date = serializers.DateTimeField(read_only=True)

    class Meta:
        model = Order
        fields = ['order_date', 'customer', 'customer_details']




class OrderItemSerializer(serializers.ModelSerializer):
    order = serializers.PrimaryKeyRelatedField(queryset=Order.objects.all())
    item_name = serializers.CharField(max_length=200)
    order_details = OrderSerializer(source='order', read_only=True)
    customer_details = CustomerSerializer(source='customer', read_only=True)
    quantity = serializers.IntegerField(default=1)

    class Meta:
        model = OrderItem
        fields = ['order', 'item_name', 'order_details','customer_details','quantity']

