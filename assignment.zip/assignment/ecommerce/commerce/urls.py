
from django.urls import path
from .views import customer_list,customer_details_view,order_list,order_details_view,orderitem_list,orderitem_details_view



urlpatterns=[
     path('customer',customer_list),
     path('customer/<int:passed_id>', customer_details_view),
     path('order',order_list),
     path('order/<int:passed_id>',order_details_view),
     path('orderitem',orderitem_list),
     path('orderitem/<int:passed_id>',orderitem_details_view)


]